.. cmake-module:: ../../rapids-cmake/cpm/thrust.cmake
