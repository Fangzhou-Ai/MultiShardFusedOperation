.. cmake-module:: ../../rapids-cmake/cpm/rmm.cmake
