.. cmake-module:: ../../rapids-cmake/cpm/find.cmake
